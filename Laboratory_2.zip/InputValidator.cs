﻿
using System;
public class InputValidator
{
    public static double ReadDouble()
    {
        double value = 0;
        while (!double.TryParse(
            Console.ReadLine()?.Replace('.', ','), out value))
        {
            Console.Write("\tОшибка ввода. Введите вещественное число: ");
        }
        return value;
    }

    public static int ReadInt()
    {
        int value = 0;
        while (!int.TryParse(
            Console.ReadLine(), out value))
        {
            Console.Write("\tОшибка ввода. Введите целое число: ");
        }
        return value;
    }

    public static long ReadLong()
    {
        long value = 0;
        while (!long.TryParse(
            Console.ReadLine(), out value))
        {
            Console.Write("\tОшибка ввода. Введите целое число: ");
        }
        return value;
    }

    public static char ReadDigit()
    {
        while (true)
        {
            string input = Console.ReadLine();
            if (input != null && input.Length == 1
                && input[0] >= '0' && input[0] <= '9')
            {
                return input[0];
            }
            Console.Write("\tВведите одну цифру от 0 до 9: ");
        }
    }

    public static int ReadPositiveInt()
    {
        int value = 0;
        while (!int.TryParse(
            Console.ReadLine(), out value) || value <= 0)
        {
            Console.Write("\tВведите целое число больше нуля: ");
        }
        return value;
    }

    public static int ReadNonNegativeInt()
    {
        int value = 0;
        while (!int.TryParse(
            Console.ReadLine(), out value) || value < 0)
        {
            Console.Write("\tВведите целое число не меньше нуля: ");
        }
        return value;
    }

    public static int ReadInt(int minValue, int maxValue)
    {
        int value = 0;
        while (!int.TryParse(
            Console.ReadLine(), out value)
            || value < minValue || value > maxValue)
        {
            Console.Write($"\tВведите число от {minValue} до {maxValue}: ");
        }
        return value;
    }

    public static string ReadNonEmptyString()
    {
       string value = Console.ReadLine();
        while (string.IsNullOrWhiteSpace(value))
        {
            Console.Write("\tСтрока не должна быть пустой: ");
            value = Console.ReadLine();
        }
        return value.Trim();
    }
}
