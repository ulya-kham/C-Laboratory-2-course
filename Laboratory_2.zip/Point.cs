﻿
using System;

public class Point
{
    private double x;
    private double y;

    public Point()
    {
        x = 0;
        y = 0;
    }

    public Point(double x, double y)
    {
        X = x;
        Y = y;
    }

    public Point(Point point)
    {
        if (point == null)
        {
            x = 0;
            y = 0;
        }
        else
        {
            this.x = point.x;
            this.y = point.y;
        }
    }

    public double X
    {
        get { return x; }
        set { x = value; }
    }

    public double Y
    {
        get { return y; }
        set { y = value; }
    }

    public override string ToString()
    {
        return $"{{{x};{y}}}";
    }


    //private double x = 0;
    //private double y = 0;
    //public Point(double x, double y)
    //{
    //    this.x = x;
    //    this.y = y;
    //}
    //public double X
    //{
    //    get { return x; }
    //}
    //public double Y
    //{
    //    get { return y; }
    //}
    //public override string ToString()
    //{
    //    return $"{{{x};{y}}}";
    //}
}
