﻿
using System;

public class Point
{
    private double _x;
    private double _y;

    public Point()
    {
        _x = 0;
        _y = 0;
    }

    public Point(double x, double y)
    {
        X = x;
        Y = y;
    }

    public Point(Point point)
    {
        if (point == null)
        {
            _x = 0;
            _y = 0;
        }
        else
        {
            this._x = point._x;
            this._y = point._y;
        }
    }

    public double X
    {
        get { return _x; }
        set { _x = value; }
    }

    public double Y
    {
        get { return _y; }
        set { _y = value; }
    }

    public override string ToString()
    {
        return $"{{{_x};{_y}}}";
    }


    //private double _x = 0;
    //private double _y = 0;
    //public Point(double x, double y)
    //{
    //    this._x = x;
    //    this._y = y;
    //}
    //public double X
    //{
    //    get { return _x; }
    //}
    //public double Y
    //{
    //    get { return _y; }
    //}
    //public override string ToString()
    //{
    //    return $"{{{_x};{_y}}}";
    //}
}
