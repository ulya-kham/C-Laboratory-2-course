﻿using System;
public class Line
{
    private Point _start;
    private Point _end;

    public Line()
    {
        _start = new Point();
        _end = new Point();
    }

    public Line(Point start, Point end)
    {
        Start = start;
        End = end;
    }

    public Line(Line line)
    {
        if (line == null)
        {
            this._start = new Point();
            this._end = new Point();
        }
        else
        {
            this._start = new Point(line._start);
            this._end = new Point(line._end);
        }
    }

    public Point Start
    {
        get { return _start; }
        set
        {
            if (value == null)
            {
                _start = new Point();
            }
            else
            {
                _start = new Point(value);
            }
        }
    }

    public Point End
    {
        get { return _end; }
        set
        {
            if (value == null)
            {
                _end = new Point();
            }
            else
            {
                _end = new Point(value);
            }
        }
    }

    public override string ToString()
    {
        return $"Линия от {_start} до {_end}";
    }

    //private Point _start = null;
    //private Point _end = null;

    //public Line(Point start, Point end)
    //{
    //    this._start = start;
    //    this._end = end;
    //}
    //public Line(double x1, double y1, double x2, double y2)
    //{
    //    this._start = new Point(x1, y1);
    //    this._end = new Point(x2, y2);
    //}
    //public Point Start
    //{
    //    get { return _start; }
    //}
    //public Point End
    //{
    //    get { return _end; }
    //}
    //public int GetLength()
    //{
    //    double dx = _end.X - _start.X;
    //    double dy = _end.Y - _start.Y;
    //    double distance = Math.Sqrt(dx * dx + dy * dy);
    //    return (int)distance;
    //}

    //public override string ToString()
    //{
    //    return $"Линия от {_start} до {_end}";
    //}
}
