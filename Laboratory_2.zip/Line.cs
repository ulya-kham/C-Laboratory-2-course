﻿using System;
public class Line
{
    private Point start;
    private Point end;

    public Line()
    {
        start = new Point();
        end = new Point();
    }

    public Line(Point start, Point end)
    {
        Start = start;
        End = end;
    }

    public Line(Line line)
    {
        if (line == null)
        {
            this.start = new Point();
            this.end = new Point();
        }
        else
        {
            this.start = new Point(line.start);
            this.end = new Point(line.end);
        }
    }

    public Point Start
    {
        get { return start; }
        set
        {
            if (value == null)
            {
                start = new Point();
            }
            else
            {
                start = new Point(value);
            }
        }
    }

    public Point End
    {
        get { return end; }
        set
        {
            if (value == null)
            {
                end = new Point();
            }
            else
            {
                end = new Point(value);
            }
        }
    }

    public override string ToString()
    {
        return $"Линия от {start} до {end}";
    }

    //private Point start = null;
    //private Point end = null;

    //public Line(Point start, Point end)
    //{
    //    this.start = start;
    //    this.end = end;
    //}
    //public Line(double x1, double y1, double x2, double y2)
    //{
    //    this.start = new Point(x1, y1);
    //    this.end = new Point(x2, y2);
    //}
    //public Point Start
    //{
    //    get { return start; }
    //}
    //public Point End
    //{
    //    get { return end; }
    //}
    //public int GetLength()
    //{
    //    double dx = end.X - start.X;
    //    double dy = end.Y - start.Y;
    //    double distance = Math.Sqrt(dx * dx + dy * dy);
    //    return (int)distance;
    //}

    //public override string ToString()
    //{
    //    return $"Линия от {start} до {end}";
    //}
}
