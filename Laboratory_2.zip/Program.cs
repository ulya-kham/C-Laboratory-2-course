﻿using System;
internal class Program
{
    private static void Main(string[] args)
    {
        bool isRunning = true;
        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("\t~~ ЛАБОРАТОРНАЯ РАБОТА №2 ~~ \n");
            Console.WriteLine("\tВыберите задание:");
            Console.WriteLine("\t1 - Точка координат");
            Console.WriteLine("\t2 - Прямая");
            Console.WriteLine("\t3 - Студент");
            Console.WriteLine("\t4 - Точка и Линия");
            Console.WriteLine("\t5 - Длина Линии");
            Console.WriteLine("\t0 - Выход");
            Console.Write("\n\tВаш выбор: ");
            int choice = InputValidator.ReadInt();
            switch (choice)
            {
                case 1:
                    ShowPointMenu();
                    break;
                case 2:
                    ShowLineMenu();
                    break;
                case 3:
                    ShowStudentMenu();
                    break;
                case 4:
                  //  ShowTask4Menu();
                    break;
                case 5:
                   // ShowLenghtMenu();
                    break;
                case 0:
                    isRunning = false;
                    break;
                default:
                    Console.WriteLine("\tТакого пункта меню нет");
                    WaitForEnter();
                    break;
            }
        }
    }
    private static void ShowPointMenu()
    {
        bool isRunning = true;
        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("\t~~ ТОЧКА КООРДИНАТ ~~ \n");
            Console.WriteLine("\tВыберите задачу:");
            Console.WriteLine("\t1. Решение задачи");
            Console.WriteLine("\t2. Демонстрация класса");
            Console.WriteLine("\t0. Назад");
            Console.Write("\n\tВаш выбор: ");
            int choice = InputValidator.ReadInt();
            switch (choice)
            {
                case 1:
                    SolveTask1();
                    break;
                case 2:
                    DemonstratePoint();
                    break;
                case 0:
                    isRunning = false;
                    break;
                default:
                    Console.WriteLine(
                        "\tТакого пункта меню нет");
                    WaitForEnter();
                    break;
            }
        }
    }
    private static void SolveTask1()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 1. ТОЧКА КООРДИНАТ ~~ \n");
        Console.WriteLine("\tСоздайте точки с разными координатами:");
        Point point1 = CreatePoint("1", null, null);
        Point point2 = CreatePoint("2", point1, null);
        Point point3 = CreatePoint("3", point1, point2);
        Console.WriteLine("\n\tРезультат:");
        Console.WriteLine($"\tТочка 1: {point1}");
        Console.WriteLine($"\tТочка 2: {point2}");
        Console.WriteLine($"\tТочка 3: {point3}");
        WaitForEnter();
    }
    private static Point CreatePoint(
        string number, Point point1, Point point2)
    {
        double x;
        double y;
        Point point;
        while (true)
        {
            Console.WriteLine($"\n\tТочка {number}");
            Console.Write("\tВведите X: ");
            x = InputValidator.ReadDouble();
            Console.Write("\tВведите Y: ");
            y = InputValidator.ReadDouble();
            point = new Point(x, y);
            if (IsDifferent(point, point1) && IsDifferent(point, point2))
            {
                return point;
            }

            Console.WriteLine("\tТакая точка уже есть");
        }
    }
    private static bool IsDifferent(Point point1, Point point2)
    {
        if (point2 == null)
        {
            return true;
        }

        return point1.X != point2.X || point1.Y != point2.Y;
    }
    private static void DemonstratePoint()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ДЕМОНСТРАЦИЯ КЛАССА - ТОЧКА ~~ \n");
        Point point1 = new Point();
        Console.WriteLine("\n\tТочка 1 (по умолчанию): " + point1);
        Point point2 = CreatePoint("2", null, null);
        Console.WriteLine("\tТочка 2 (с параметрами): " + point2);
        Console.WriteLine("\n\tКопируем точку 2 в точку 3");
        Point point3 = new Point(point2);
        Console.WriteLine("\tТочка 3 (копирование): " + point3);
        Console.WriteLine("\n\tИзменяем координаты точки 2");
        Console.Write("\tВведите новый X: ");
        point2.X = InputValidator.ReadDouble();
        Console.Write("\tВведите новый Y: ");
        point2.Y = InputValidator.ReadDouble();
        Console.WriteLine("\n\tРезультат:");
        Console.WriteLine($"\tТочка 1: {point1}");
        Console.WriteLine($"\tТочка 2: {point2}");
        Console.WriteLine($"\tТочка 3: {point3}");
        WaitForEnter();
    }



    private static void ShowLineMenu()
    {
        bool isRunning = true;
        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("\t~~ ПРЯМАЯ ~~ \n");
            Console.WriteLine("\tВыберите задачу:");
            Console.WriteLine("\t1. Решение задачи");
            Console.WriteLine("\t2. Демонстрация класса");
            Console.WriteLine("\t0. Назад");
            Console.Write("\n\tВаш выбор: ");
            int choice = InputValidator.ReadInt();
            switch (choice)
            {
                case 1:
                   SolveTask2();
                    break;
                case 2:
                    DemonstrateLine();
                    break;
                case 0:
                    isRunning = false;
                    break;
                default:
                    Console.WriteLine(
                        "\tТакого пункта меню нет");
                    WaitForEnter();
                    break;
            }
        }
    }
    private static void SolveTask2()
    {
        Console.Clear();
        Console.WriteLine("\t~~ ЗАДАНИЕ 2. ПРЯМАЯ ~~\n");
        Line line1 = new Line(new Point(1, 3), new Point(23, 8));
        Line line2 = new Line(new Point(5, 10), new Point(25, 10));
        Line line3 = new Line(line1.Start, line2.End);
        Console.WriteLine("\tИсходные линии:");
        Console.WriteLine($"\tЛиния 1: {line1}");
        Console.WriteLine($"\tЛиния 2: {line2}");
        Console.WriteLine($"\tЛиния 3: {line3}");
        Console.WriteLine("\n\t4. Введите новые координаты Линии 1:");
        Point newStart1 = ReadPoint("Начало");
        while (!IsDifferent(newStart1, line1.Start))
        {
            Console.WriteLine("\tКоординаты совпадают!");
            newStart1 = ReadPoint("Начало");
        }
        Point newEnd1 = ReadPoint("Конец");
        while (!IsDifferent(newEnd1, line1.End))
        {
            Console.WriteLine("\tКоординаты совпадают!");
            newEnd1 = ReadPoint("Конец");
        }
        Console.WriteLine("\n\tВведите новые координаты Линии 2:");
        Point newStart2 = ReadPoint("Начало");
        while (!IsDifferent(newStart2, line2.Start))
        {
            Console.WriteLine("\tКоординаты совпадают!");
            newStart2 = ReadPoint("Начало");
        }

        Point newEnd2 = ReadPoint("Конец");
        while (!IsDifferent(newEnd2, line2.End))
        {
            Console.WriteLine("\tКоординаты совпадают!");
            newEnd2 = ReadPoint("Конец");
        }
        line1.Start = newStart1;
        line1.End = newEnd1;
        line2.Start = newStart2;
        line2.End = newEnd2;
        line3.Start = line1.Start;
        line3.End = line2.End;
        Console.WriteLine("\n\tПосле обновления:");
        Console.WriteLine($"\tЛиния 1: {line1}");
        Console.WriteLine($"\tЛиния 2: {line2}");
        Console.WriteLine($"\tЛиния 3: {line3}");
        Console.WriteLine("\n\t5. Изменяем координаты Линии 1," +
            "чтобы Линия 3 не изменилась:");
        Point newEnd = ReadPoint("Новый конец");
        while (!IsDifferent(newEnd, line1.End))
        {
            Console.WriteLine("\tКоординаты совпадают!");
            newEnd = ReadPoint("Новый конец");
        }
        line1.End = newEnd;
        Console.WriteLine("\n\tПосле изменения:");
        Console.WriteLine($"\tЛиния 1: {line1}");
        Console.WriteLine($"\tЛиния 3 (не изменилась): {line3}");
        WaitForEnter();
    }
    private static Point ReadPoint(string name)
    {
        Console.Write($"\t{name} X: ");
        double x = InputValidator.ReadDouble();
        Console.Write($"\t{name} Y: ");
        double y = InputValidator.ReadDouble();
        return new Point(x, y);
    }
    private static void DemonstrateLine()
    {
        Console.Clear();
        Console.WriteLine("\t~~ Демонстрация класса - Линия ~~\n");
        Console.WriteLine("\t1. Создаём Линию 1");
        Line line1 = new Line();
        Console.WriteLine("\tЛиния 1 (по умолчанию): " + line1);
        Console.WriteLine("\n\t2. Введите координаты Линии 2:");
        Point start = ReadPoint("Начало");
        Point end = ReadPoint("Конец");
        Line line2 = new Line(start, end);
        Console.WriteLine("\tЛиния 2 (с параметрами): " + line2);
        Console.WriteLine("\n\t3. Создаём Линию 3 - копия Линии 2");
        Line line3 = new Line(line2);
        Console.WriteLine("\tЛиния 3 (копия): " + line3);
        Console.WriteLine("\n\tВведите новый конец Линии 2:");
        Point newEnd2 = ReadPoint("Конец");
        while (!IsDifferent(newEnd2, line2.End))
        {
            Console.WriteLine("\tКоординаты совпадают!");
            newEnd2 = ReadPoint("Конец");
        }
        line2.End = newEnd2;
        Console.WriteLine("\tЛиния 2 (изменена): " + line2);
        Console.WriteLine("\tЛиния 3 (не изменилась): " + line3);
        Console.WriteLine("\n\t4. Создаём Линию 4");
        Line line4 = new Line();
        Console.WriteLine("\tПо умолчанию: " + line4);
        line4.Start = null;
        Console.WriteLine("\tПрисваиваем началу null: " + line4);
        Console.WriteLine("\tКопируем координаты Линии 3");
        line4.Start = line3.Start;
        line4.End = line3.End;
        Console.WriteLine("\tПосле копирования: " + line4);
        Console.WriteLine("\n\t5. Введите новое начало Линии 4:");
        Point newStart4 = ReadPoint("Начало");
        while (!IsDifferent(newStart4, line4.Start))
        {
            Console.WriteLine("\tКоординаты совпадают!");
            newStart4 = ReadPoint("Начало");
        }
        line4.Start = newStart4;
        Console.WriteLine("\tРезультат: " + line4);
        Console.WriteLine("\n\t6. Линия 5 из концов Линий 2 и 4");
        Line line5 = new Line(line2.End, line4.End);
        Console.WriteLine("\tРезультат: " + line5);
        Console.WriteLine($"\n\tЛиния 1: {line1}");
        Console.WriteLine($"\tЛиния 2: {line2}");
        Console.WriteLine($"\tЛиния 3: {line3}");
        Console.WriteLine($"\tЛиния 4: {line4}");
        Console.WriteLine($"\tЛиния 5: {line5}");
        WaitForEnter();
    }




    private static void ShowStudentMenu()
    {
        bool isRunning = true;
        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("\t~~ СТУДЕНТ ~~ \n");
            Console.WriteLine("\tВыберите задачу:");
            Console.WriteLine("\t1. Решение задачи");
            Console.WriteLine("\t2. Демонстрация класса");
            Console.WriteLine("\t0. Назад");
            Console.Write("\n\tВаш выбор: ");
            int choice = InputValidator.ReadInt();
            switch (choice)
            {
                case 1:
                    SolveTask3();
                    break;
                case 2:
                    DemonstrateStudent();
                    break;
                case 0:
                    isRunning = false;
                    break;
                default:
                    Console.WriteLine(
                        "\tТакого пункта меню нет");
                    WaitForEnter();
                    break;
            }
        }
    }
    private static void SolveTask3()
    {
        Console.Clear();
        Console.WriteLine("\t~~ЗАДАНИЕ 3. СТУДЕНТ ~~\n");
        Student vasya = new Student("Вася", new int[] { 3, 4, 5 });
        Console.WriteLine("\t1. Создан студент Вася:");
        Console.WriteLine("\t" + vasya);
        Student petya = new Student("Петя", vasya.Grades);
        Console.WriteLine("\n\t2. Создан студент Петя:");
        Console.WriteLine("\t" + petya);
        petya.Grades[0] = 5;
        Console.WriteLine("\n\t3. Первая оценка Пети изменена на 5.");
        Console.WriteLine("\t" + vasya);
        Console.WriteLine("\t" + petya);
        Student andrey = new Student("Андрей", vasya.Grades);
        Console.WriteLine("\n\t4. Создан студент Андрей:");
        Console.WriteLine("\t" + andrey);
        Console.WriteLine("\n\tИзменим оценки Васи.");
        int count = vasya.Grades.Length;
        int[] newGrades = new int[count];
        for (int i = 0; i < count; i++)
        {
            Console.Write($"\tВведите оценку {i + 1} от 2 до 5: ");
            newGrades[i] = InputValidator.ReadInt(2, 5);
        }
        vasya.Grades = newGrades;
        Console.WriteLine("\n\tПосле изменения оценок:");
        Console.WriteLine("\t" + vasya);
        Console.WriteLine("\t" + andrey);
        WaitForEnter();
    }
    private static void DemonstrateStudent()
    {
        Console.Clear();
        Console.WriteLine("\t~~ Демонстрация класса - Студент ~~\n");
        Console.WriteLine("\t1. Создаём студента конструктором " +
            "по умолчанию");
        Student student1 = new Student();
        Console.WriteLine("\tСтудент 1. " + student1);
        Console.Write("\n\t2. Введите имя студента: ");
        string name = InputValidator.ReadNonEmptyString();
        Console.Write("\tКоличество оценок: ");
        int count = InputValidator.ReadPositiveInt();
        int[] grades = new int[count];
        for (int i = 0; i < count; i++)
        {
            Console.Write($"\tОценка {i + 1} от 2 до 5: ");
            grades[i] = InputValidator.ReadInt(2, 5);
        }
        Student student2 = new Student(name, grades);
        Console.WriteLine("\n\tСтудент 2."+ student2);
        Console.WriteLine(
            "\n\t3. Создаём студента 3 - копию студента 2");
        Student student3 = new Student(student2);
        Console.WriteLine("\tСтудент 3. " + student3);
        Console.WriteLine(
            "\n\tИзменим первую оценку студента 2.");
        Console.Write("\tНовая оценка от 2 до 5: ");
        student2.Grades[0] = InputValidator.ReadInt(2, 5);
        Console.WriteLine("\tСтудент 2. " + student2);
        Console.WriteLine("\tСтудент 3. " + student3);
        Console.WriteLine("\n\t4. Меняем имя студента 3.");
        Console.Write("\tВведите новое имя: ");
        student3.Name = InputValidator.ReadNonEmptyString();
        Console.WriteLine("\tСтудент 3: " + student3);
        Console.WriteLine("\n\t5. Присваиваем оценки студента 2 = null");
        student2.Grades = null;
        Console.WriteLine("\tСтудент 2: " + student2);
        Console.WriteLine("\n\t6. Введём оценки для студента 1.");
        Console.Write("\tКоличество оценок: ");
        int count1 = InputValidator.ReadPositiveInt();
        int[] grades1 = new int[count1];
        for (int i = 0; i < count1; i++)
        {
            Console.Write($"\tОценка {i + 1} от 2 до 5: ");
            grades1[i] = InputValidator.ReadInt(2, 5);
        }
        student1.Grades = grades1;
        Console.WriteLine("\n\tСтудент 1: " + student1);
        Console.WriteLine("\tСтудент 2: " + student2);
        Console.WriteLine("\tСтудент 3: " + student3);
        WaitForEnter();
    }
    private static void WaitForEnter()
    {
        Console.Write(
            "\n\tНажмите Enter, чтобы продолжить...");
        Console.ReadLine();
    }



    //private static void ShowTask4Menu()
    //{
    //    bool isRunning = true;
    //    while (isRunning)
    //    {
    //        Console.Clear();
    //        Console.WriteLine("\t~~ ЗАДАНИЕ 4 ~~ \n");
    //        Console.WriteLine("\t1. Точки (4.1)");
    //        Console.WriteLine("\t2. Линии (4.2)");
    //        Console.WriteLine("\t0. Назад");
    //        Console.Write("\n\tВаш выбор: ");
    //        int choice = InputValidator.ReadInt();
    //        switch (choice)
    //        {
    //            case 1:
    //                SolveTask4_1();
    //                break;
    //            case 2:
    //                SolveTask4_2();
    //                break;
    //            case 0:
    //                isRunning = false;
    //                break;
    //            default:
    //                Console.WriteLine("\tТакого пункта меню нет");
    //                WaitForEnter();
    //                break;
    //        }
    //    }
    //}
    //private static void SolveTask4_1()
    //{
    //    Console.Clear();
    //    Console.WriteLine("\t~~ ЗАДАНИЕ 4.1. ТОЧКА ~~\n");
    //    Console.WriteLine("\tДанные переданы:\n");
    //    Point p1 = new Point(3, 5);
    //    Point p2 = new Point(25, 6);
    //    Point p3 = new Point(7, 8);
    //    Console.WriteLine("\tРезультат:");
    //    Console.WriteLine("\tТочка 1: " + p1);
    //    Console.WriteLine("\tТочка 2: " + p2);
    //    Console.WriteLine("\tТочка 3: " + p3);
    //    Console.WriteLine("\n\tДанные вводятся вручную:\n");
    //    Console.Write("\tВведите X для Точки 1: ");
    //    double x1 = InputValidator.ReadDouble();
    //    Console.Write("\tВведите Y для Точки 1: ");
    //    double y1 = InputValidator.ReadDouble();
    //    Point manualP1 = new Point(x1, y1);
    //    Console.Write("\n\tВведите X для Точки 2: ");
    //    double x2 = InputValidator.ReadDouble();
    //    Console.Write("\tВведите Y для Точки 2: ");
    //    double y2 = InputValidator.ReadDouble();
    //    Point manualP2 = new Point(x2, y2);
    //    Console.Write("\n\tВведите X для Точки 3: ");
    //    double x3 = InputValidator.ReadDouble();
    //    Console.Write("\tВведите Y для Точки 3: ");
    //    double y3 = InputValidator.ReadDouble();
    //    Point manualP3 = new Point(x3, y3);
    //    Console.WriteLine("\n\tРезультат:");
    //    Console.WriteLine("\tТочка 1: " + manualP1);
    //    Console.WriteLine("\tТочка 2: " + manualP2);
    //    Console.WriteLine("\tТочка 3: " + manualP3);
    //    WaitForEnter();
    //}

    //private static void SolveTask4_2()
    //{
    //    Console.Clear();
    //    Console.WriteLine("\t~~ ЗАДАНИЕ 4.2. ЛИНИЯ ~~\n");
    //    Console.WriteLine("\tДанные переданы:\n");
    //    Line line1 = new Line(1, 3, 23, 8);
    //    Line line2 = new Line(5, 10, 25, 10);
    //    Line line3 = new Line(line1.Start, line2.End);
    //    Console.WriteLine("\tРезультат:");
    //    Console.WriteLine("\tЛиния 1: " + line1);
    //    Console.WriteLine("\tЛиния 2: " + line2);
    //    Console.WriteLine("\tЛиния 3: " + line3);
    //    Console.WriteLine("\n\tДанные вводятся вручную:\n");
    //    Console.WriteLine("\tЛиния 1 (через 2 точки)");
    //    Point manualStart1 = ReadPoint("Начало");
    //    Point manualEnd1 = ReadPoint("Конец");
    //    Line manualLine1 = new Line(manualStart1, manualEnd1);
    //    Console.WriteLine("\n\tЛиния 2 (через 4 числа)");
    //    Console.Write("\tX1: ");
    //    double x1 = InputValidator.ReadDouble();
    //    Console.Write("\tY1: ");
    //    double y1 = InputValidator.ReadDouble();
    //    Console.Write("\tX2: ");
    //    double x2 = InputValidator.ReadDouble();
    //    Console.Write("\tY2: ");
    //    double y2 = InputValidator.ReadDouble();
    //    Line manualLine2 = new Line(x1, y1, x2, y2);
    //    Console.WriteLine(
    //        "\n\tЛиния 3 (автоматически)");
    //    Line manualLine3 = new Line(manualLine1.Start, manualLine2.End);
    //    Console.WriteLine("\n\tРезультат ручного ввода:");
    //    Console.WriteLine("\tЛиния 1: " + manualLine1);
    //    Console.WriteLine("\tЛиния 2: " + manualLine2);
    //    Console.WriteLine("\tЛиния 3: " + manualLine3);
    //    WaitForEnter();
    //}

    //private static void ShowLenghtMenu()
    //{
    //    Console.Clear();
    //    Console.WriteLine("\t~~ ЗАДАНИЕ 5. ДЛИНА ЛИНИИ ~~\n");
    //    Console.WriteLine("\tДанные переданы:\n");
    //    Point start = new Point(1, 1);
    //    Point end = new Point(10, 15);
    //    Console.WriteLine("\tТочка начала: " + start + 
    //        ", Точка конца: " + end);
    //    Line line = new Line(start, end);
    //    Console.WriteLine("\tСоздана линия: " + line);
    //    Console.WriteLine("\tДлина линии: " + line.GetLength());
    //    Console.WriteLine("\n\tДанные вводятся вручную:\n");
    //    Console.WriteLine("\tВведите координаты начала");
    //    Point manualStart = ReadPoint("Начало");
    //    Console.WriteLine("\tВведите координаты конца");
    //    Point manualEnd = ReadPoint("Конец");
    //    Line manualLine = new Line(manualStart, manualEnd);
    //    Console.WriteLine("\n\tРезультат:");
    //    Console.WriteLine("\tЛиния: " + manualLine);
    //    Console.WriteLine("\tДлина: " + manualLine.GetLength());
    //    WaitForEnter();
    //}
}
