﻿
using System;

public class Student
{
    private string _name;
    private int[] _grades;

    public Student()
    {
        _name = "Студент X";
        _grades = new int[0];
    }

    public Student(string name, int[] grades)
    {
        Name = name;
        Grades = grades;
    }

    public Student(Student student)
    {
        if (student == null)
        {
            this._name = "Студент X";
            this._grades = new int[0];
        }
        else
        {
            this._name = student._name;
            this._grades = new int[student._grades.Length];

            for (int i = 0; i < this._grades.Length; i++)
            {
                this._grades[i] = student._grades[i];
            }
        }
    }

    public string Name
    {
        get { return _name; }
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                _name = "Студент X";
            }
            else
            {
                _name = value;
            }
        }
    }

    public int[] Grades
    {
        get { return _grades; }
        set
        {
            if (value == null)
            {
                _grades = new int[0];
            }
            else
            {
                _grades = new int[value.Length];
                for (int i = 0; i < value.Length; i++)
                {
                    _grades[i] = value[i];
                }
            }
        }
    }

    public override string ToString()
    {
        string result = _name + ": [";
        for (int i = 0; i < _grades.Length; i++)
        {
            if (i > 0)
            {
                result = result + ", ";
            }
            result = result + _grades[i];
        }
        return result + "]";
    }

}
