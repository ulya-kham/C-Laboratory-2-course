﻿
using System;

public class Student
{
    private string name;
    private int[] grades;

    public Student()
    {
        name = "Студент X";
        grades = new int[0];
    }

    public Student(string name, int[] grades)
    {
        Name = name;
        Grades = grades;
    }

    public Student(Student student)
    {
        if (student == null)
        {
            this.name = "Студент X";
            this.grades = new int[0];
        }
        else
        {
            this.name = student.name;
            this.grades = new int[student.grades.Length];

            for (int i = 0; i < this.grades.Length; i++)
            {
                this.grades[i] = student.grades[i];
            }
        }
    }

    public string Name
    {
        get { return name; }
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                name = "Студент X";
            }
            else
            {
                name = value;
            }
        }
    }

    public int[] Grades
    {
        get { return grades; }
        set
        {
            if (value == null)
            {
                grades = new int[0];
            }
            else
            {
                grades = new int[value.Length];
                for (int i = 0; i < value.Length; i++)
                {
                    grades[i] = value[i];
                }
            }
        }
    }

    public override string ToString()
    {
        string result = name + ": [";
        for (int i = 0; i < grades.Length; i++)
        {
            if (i > 0)
            {
                result = result + ", ";
            }
            result = result + grades[i];
        }
        return result + "]";
    }

}
